function mask = createCirclesMask(sz,centers,radii)

narginchk(3,3)
if numel(sz) == 2
	% SIZE specified
	xDim = sz(1);
	yDim = sz(2);
else
	% IMAGE specified
	[xDim,yDim,~] = size(sz);
end
mask = false(xDim,yDim);
if isempty(radii)
	return
end
Rmax = ceil(max(radii));
bw = false(2*Rmax+1);
bw(Rmax+1,Rmax+1) = 1;
D = bwdist(bw);

centers = round(centers);
xc = centers(:,1);
yc = centers(:,2);
Rim = ceil(radii);

for k = 1:numel(radii)
	% Create "stamp"
	rLo = Rmax-Rim(k);
	rHi = Rmax+Rim(k);
	circle_k = D(1 + (rLo:rHi),1 + (rLo:rHi)) <= radii(k);
	%Compute subscripts for stamp location
	r1 = max(1,yc(k) - Rim(k));
	r2 = min(yDim,yc(k) + Rim(k));
	c1 = max(1,xc(k) - Rim(k));
	c2 = min(yDim,xc(k) + Rim(k));
	targetSize = [r2-r1+1 c2-c1+1];
	if any(targetSize~=size(circle_k))
		% TRIM REQUIRED; Trim circle stamps that overlap image border:
		offsets = [yc(k)-Rim(k),yc(k)+Rim(k),xc(k)-Rim(k),xc(k)+Rim(k)];
		trimAmounts = [r1-offsets(1) offsets(2)-r2 c1-offsets(3) offsets(4)-c2];%[top bottom left right]
		circle_k = circle_k(1+trimAmounts(1):end-trimAmounts(2),1+trimAmounts(3):end-trimAmounts(4));
	end
	if ~isempty(circle_k) && all([r1>0,r2<=xDim,c1>0,c2<=yDim])
		mask(r1:r2,c1:c2) = mask(r1:r2,c1:c2) | circle_k;
	end
end
