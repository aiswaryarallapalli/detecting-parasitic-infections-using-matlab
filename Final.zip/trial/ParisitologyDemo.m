%% Clean slate
clear; close all;clc;

%% Loading Images
imagedir = fullfile(pwd,'.\BloodSmearImages\babesiosis');
imgSet = imageSet(imagedir)

%Create a display of all images in a grid format
togglefig('Parasitic Images')
ax = gobjects(imgSet.Count,1);
for x = 1:imgSet.Count
   
    %Appending each image to object array
ax(x) = subplot(floor(sqrt(imgSet.Count)),ceil(sqrt(imgSet.Count)),x);
[~,currentName] = fileparts(imgSet.ImageLocation{x});
  imshow(read(imgSet,x))
title([num2str(x),'.' currentName],'fontsize',7)
end

%% Select one image from dataset
targetImgNum = 1;
togglefig('Parasitic Images')
[~,imgName] = fileparts(imgSet.ImageLocation{targetImgNum});

%Marking target with red border
set(ax,'xcolor','r','ycolor','r','xtick',[],'ytick',[],'linewidth',2,'visible','off')
set(ax(targetImgNum),'visible','on');
targetImage = imread(imgSet.ImageLocation{targetImgNum});


%% Segmentation

%Using image segmenter app
cellMask = segmentImageFcn(targetImage);
% Remove objects containing fewer than �n� pixels thereby 'cleaning' the image
cellMask = bwareaopen(cellMask,100);
togglefig('Cell Mask',true); imshow(cellMask);

%% Try detecting edges

%Finds edges by looking for zero-crossings after filtering img with a Laplacian of Gaussian (LoG) filter
% with a threshold of 0.001
edges = edge(rgb2gray(targetImage),'LOG',0.001);
edges = bwareaopen(edges,60,8);
% togglefig('Edge Mask')
%Display target image vs edges
subplot(1,2,1) ; imshow(targetImage)
subplot(1,2,2) ; imshow(edges)

%% Combine the edges (logically) with the segmented regions
togglefig('Cell Mask')
tmp = cellMask & ~edges;
tmp = bwareaopen(tmp,100);
imshow(tmp);

%% Improve the edge mask

morphed1 = imclose(edges, strel('Disk',3,4));
morphed1 = bwmorph(morphed1, 'skeleton', Inf);
morphed1 = bwmorph(morphed1, 'spur', Inf);
morphed1 = bwpropfilt(morphed1,'Perimeter',[80 Inf]);
togglefig('Edge Mask',true)
imshow(morphed1);
imshow(cellMask & ~morphed1);

%%
togglefig('Babesiosis Images',true)
refreshImages
for x = 1:imgSet.Count
mask = refinedMask(getimage(ax(x)));
showMaskAsOverlay(0.5,mask,'b',[],ax(x))
drawnow
end


%% Applying circle detection algorithm on our target image

grayscale = rgb2gray(targetImage);
detectCircles = @(x) imfindcircles(x,[20 35], ...
'Sensitivity',0.89, ...
'EdgeThreshold',0.04, ...
'Method','TwoStage', ...
'ObjectPolarity','Dark');
[centers, radx, metric] = detectCircles(grayscale);

togglefig('Target Image',true)
imshow(targetImage)
viscircles(centers,radx,'edgecolor','g')
title(sprintf('%i Cells Detected',numel(radx)),'fontsize',14);

%% Trying to bring all images to same greyscale threshold

togglefig('Exploration',1)
infectionThreshold = 135;
infection = grayscale <= infectionThreshold;
subplot(1,2,1)
imshow(targetImage)
showMaskAsOverlay(1,infection,'r');
subplot(1,2,2)
tmpImg = read(imgSet,9);
imshow(tmpImg)
infection = rgb2gray(tmpImg) <= infectionThreshold;
showMaskAsOverlay(1,infection,'r');

%% So which cells, and what fraction of cells, are infected?

[centers,radx] = detectCircles(grayscale);
isInfected = false(numel(radx),1);
nCells = numel(isInfected);

% Creating a "mesh" can be useful:
x = 1:size(grayscale,2);
y = 1:size(grayscale,1);
[xx,yy] = meshgrid(x,y);

togglefig('Grayscale',true);
imshow(grayscale)
infectionMask = false(size(grayscale));
for x = 1:numel(radx)
mask = hypot(xx - centers(x,1), yy - centers(x,2)) <= radx(x);
currentCellImage = grayscale;
currentCellImage(~mask) = 0;
infection = currentCellImage > 0 & currentCellImage < infectionThreshold;

infectionMask = infectionMask | infection;
isInfected(x) = any(infection(:));
if isInfected(x)
showMaskAsOverlay(0.3,mask,'g',[],false);
end
end
showMaskAsOverlay(0.5,infectionMask,'r',[],false)
title(sprintf('%i of %i (%0.1f%%) Infected',...
sum(isInfected),numel(isInfected),100*sum(isInfected)/numel(isInfected)),'fontsize',14,'color','r');

wsImg = watershed(grayscale);
showMaskAsOverlay(0.8, wsImg==0, 'g')
title('Classic "Oversegmentation"','fontsize',14);

%% Is this more generalizable?

togglefig('Babesiosis Images',true)
refreshImages;
drawnow

for x = 1:imgSet.Count
[percentInfected,centers,radx,isInfected,infectionMask] = ...
testForInfection(getimage(ax(x)),targetImage,...
infectionThreshold,detectCircles);
title(ax(x),...
['Pct Infection: ', num2str(percentInfected,2),...
' (' num2str(sum(isInfected)),...
' of ' num2str(numel(isInfected)) ')']);
viscircles(ax(x),centers,radx,'edgecolor','b')
% createCirclesMask
infectedCellsMask = createCirclesMask(targetImage,...
centers(isInfected,:),...
radx(isInfected));
showMaskAsOverlay(0.3,infectedCellsMask,'g',ax(x),false);
showMaskAsOverlay(0.5,infectionMask,'r',ax(x),false);
drawnow
end